
import os
import base64
import requests
import json
from PIL import Image
import colorsys
import logging

class AIImageAnalyzer:
    """AI-powered image analyzer using Gemini API"""
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.gemini_api_key = os.getenv('GEMINI_API_KEY')
        if not self.gemini_api_key:
            raise ValueError("GEMINI_API_KEY environment variable is required")
    
    def analyze_image_with_ai(self, image_path):
        """Analyze image using Gemini AI for neumorphic design parameters"""
        try:
            # Convert image to base64
            with Image.open(image_path) as img:
                # Convert to RGB if necessary
                if img.mode != 'RGB':
                    img = img.convert('RGB')
                
                # Resize for API efficiency (max 1024px)
                if max(img.size) > 1024:
                    ratio = 1024 / max(img.size)
                    new_size = tuple(int(dim * ratio) for dim in img.size)
                    img = img.resize(new_size, Image.Resampling.LANCZOS)
                
                # Save to memory as JPEG
                import io
                buffer = io.BytesIO()
                img.save(buffer, format='JPEG', quality=85)
                image_data = base64.b64encode(buffer.getvalue()).decode()
            
            # Prepare Gemini API request
            prompt = """
            Analyze this image for neumorphic (soft UI) design parameters. Please provide a detailed analysis and suggest optimal values for:

            1. Background color (dominant color that works for neumorphism)
            2. Button/element color (slightly different from background)
            3. Shadow colors (light and dark variants)
            4. Blur amount (based on image softness/sharpness)
            5. Shadow intensity (based on existing shadows/contrast)
            6. Border radius (based on image style - sharp vs rounded)
            7. X/Y offset values (based on lighting direction)
            8. Shadow types needed (inner shadows, drop shadows, multiple layers)

            Consider the image's:
            - Color palette and harmony
            - Lighting direction and intensity
            - Visual style (modern, classic, minimalist, etc.)
            - Contrast levels
            - Existing shadows and highlights

            Return your analysis in this exact JSON format:
            {
                "backgroundColor": "#hexcolor",
                "buttonColor": "#hexcolor", 
                "lightShadowColor": "#hexcolor",
                "darkShadowColor": "#hexcolor",
                "xOffset": number,
                "yOffset": number,
                "radius": number,
                "intensity": number,
                "blur": number,
                "shadowTypes": {
                    "dropShadow": boolean,
                    "innerShadow": boolean,
                    "multipleDropShadows": boolean,
                    "multipleInnerShadows": boolean
                },
                "additionalShadows": [
                    {
                        "type": "drop|inner",
                        "xOffset": number,
                        "yOffset": number,
                        "blur": number,
                        "color": "#hexcolor",
                        "opacity": number
                    }
                ],
                "designStyle": "modern|classic|minimalist|organic",
                "lightingDirection": "top-left|top-right|bottom-left|bottom-right",
                "confidence": number
            }
            """
            
            url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key={self.gemini_api_key}"
            
            payload = {
                "contents": [{
                    "parts": [
                        {"text": prompt},
                        {
                            "inline_data": {
                                "mime_type": "image/jpeg",
                                "data": image_data
                            }
                        }
                    ]
                }],
                "generationConfig": {
                    "temperature": 0.4,
                    "topK": 32,
                    "topP": 1,
                    "maxOutputTokens": 2048,
                }
            }
            
            headers = {
                "Content-Type": "application/json"
            }
            
            response = requests.post(url, headers=headers, json=payload)
            
            if response.status_code == 200:
                result = response.json()
                
                if 'candidates' in result and len(result['candidates']) > 0:
                    content = result['candidates'][0]['content']['parts'][0]['text']
                    
                    # Extract JSON from response
                    import re
                    json_match = re.search(r'\{.*\}', content, re.DOTALL)
                    if json_match:
                        ai_analysis = json.loads(json_match.group())
                        
                        # Validate and sanitize the response
                        return self._process_ai_response(ai_analysis)
                    else:
                        self.logger.warning("No valid JSON found in AI response")
                        return self._fallback_analysis(image_path)
                else:
                    self.logger.warning("No candidates in AI response")
                    return self._fallback_analysis(image_path)
            else:
                self.logger.error(f"Gemini API error: {response.status_code} - {response.text}")
                return self._fallback_analysis(image_path)
                
        except Exception as e:
            self.logger.error(f"AI analysis error: {str(e)}")
            return self._fallback_analysis(image_path)
    
    def _process_ai_response(self, ai_analysis):
        """Process and validate AI response"""
        try:
            # Validate required fields and set defaults
            processed = {
                'success': True,
                'backgroundColor': ai_analysis.get('backgroundColor', '#e0e0e0'),
                'buttonColor': ai_analysis.get('buttonColor', '#f0f0f0'),
                'lightShadowColor': ai_analysis.get('lightShadowColor', '#ffffff'),
                'darkShadowColor': ai_analysis.get('darkShadowColor', '#bebebe'),
                'suggestedParameters': {
                    'xOffset': max(1, min(30, ai_analysis.get('xOffset', 10))),
                    'yOffset': max(1, min(30, ai_analysis.get('yOffset', 10))),
                    'radius': max(0, min(100, ai_analysis.get('radius', 50))),
                    'intensity': max(10, min(100, ai_analysis.get('intensity', 50))),
                    'blur': max(5, min(50, ai_analysis.get('blur', 20))),
                    'backgroundColor': ai_analysis.get('backgroundColor', '#e0e0e0')
                },
                'shadowTypes': ai_analysis.get('shadowTypes', {
                    'dropShadow': True,
                    'innerShadow': False,
                    'multipleDropShadows': False,
                    'multipleInnerShadows': False
                }),
                'additionalShadows': ai_analysis.get('additionalShadows', []),
                'designStyle': ai_analysis.get('designStyle', 'modern'),
                'lightingDirection': ai_analysis.get('lightingDirection', 'top-left'),
                'confidence': ai_analysis.get('confidence', 0.8),
                'aiAnalysis': True
            }
            
            return processed
            
        except Exception as e:
            self.logger.error(f"Error processing AI response: {str(e)}")
            return self._fallback_analysis(None)
    
    def _fallback_analysis(self, image_path):
        """Fallback to basic analysis if AI fails"""
        from image_processor import ImageProcessor
        
        if image_path:
            processor = ImageProcessor()
            result = processor.analyze_image(image_path)
            
            if result.get('success'):
                # Enhance with shadow type suggestions
                result['shadowTypes'] = {
                    'dropShadow': True,
                    'innerShadow': False,
                    'multipleDropShadows': False,
                    'multipleInnerShadows': False
                }
                result['additionalShadows'] = []
                result['lightShadowColor'] = '#ffffff'
                result['darkShadowColor'] = '#bebebe'
                result['buttonColor'] = result.get('suggestedParameters', {}).get('backgroundColor', '#f0f0f0')
                result['aiAnalysis'] = False
                
            return result
        else:
            return {
                'success': False,
                'error': 'Fallback analysis failed',
                'aiAnalysis': False
            }
