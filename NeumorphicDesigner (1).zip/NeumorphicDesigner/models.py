from app import db
from datetime import datetime

class Design(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    x_offset = db.Column(db.Integer, default=10)
    y_offset = db.Column(db.Integer, default=10)
    radius = db.Column(db.Integer, default=50)
    intensity = db.Column(db.Integer, default=50)
    blur = db.Column(db.Integer, default=20)
    background_color = db.Column(db.String(7), default='#e0e0e0')
    shape = db.Column(db.String(20), default='rectangle')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'xOffset': self.x_offset,
            'yOffset': self.y_offset,
            'radius': self.radius,
            'intensity': self.intensity,
            'blur': self.blur,
            'backgroundColor': self.background_color,
            'shape': self.shape,
            'created_at': self.created_at.isoformat()
        }