import os
import json
from flask import render_template, request, jsonify, current_app
from werkzeug.utils import secure_filename
from app import app, db
from models import Design
from image_processor import ImageProcessor
from ai_analyzer import AIImageAnalyzer

ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'svg'}

def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route('/')
def index():
    """Main page with the neumorphism generator interface"""
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload_file():
    """Handle image upload and analysis"""
    try:
        if 'file' not in request.files:
            return jsonify({'error': 'No file selected'}), 400
        
        file = request.files['file']
        if file.filename == '':
            return jsonify({'error': 'No file selected'}), 400
        
        if file and file.filename and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            filepath = os.path.join(current_app.config['UPLOAD_FOLDER'], filename)
            file.save(filepath)
            
            # Process the image with AI first, fallback to basic processor
            try:
                ai_analyzer = AIImageAnalyzer()
                analysis_result = ai_analyzer.analyze_image_with_ai(filepath)
            except Exception as e:
                current_app.logger.warning(f"AI analysis failed, using basic processor: {str(e)}")
                processor = ImageProcessor()
                analysis_result = processor.analyze_image(filepath)
            
            # Clean up uploaded file
            os.remove(filepath)
            
            return jsonify(analysis_result)
        else:
            return jsonify({'error': 'Invalid file type. Please upload PNG, JPG, or SVG files.'}), 400
    
    except Exception as e:
        current_app.logger.error(f"Upload error: {str(e)}")
        return jsonify({'error': 'Failed to process image'}), 500

@app.route('/generate-css', methods=['POST'])
def generate_css():
    """Generate CSS based on provided parameters"""
    try:
        data = request.get_json()
        
        # Extract parameters
        x_offset = data.get('xOffset', 10)
        y_offset = data.get('yOffset', 10)
        radius = data.get('radius', 50)
        intensity = data.get('intensity', 50)
        blur = data.get('blur', 20)
        background_color = data.get('backgroundColor', '#e0e0e0')
        
        # Generate CSS
        css_code = generate_neumorphic_css(
            x_offset, y_offset, radius, intensity, blur, background_color
        )
        
        return jsonify({'css': css_code})
    
    except Exception as e:
        current_app.logger.error(f"CSS generation error: {str(e)}")
        return jsonify({'error': 'Failed to generate CSS'}), 500

def generate_neumorphic_css(x_offset, y_offset, radius, intensity, blur, bg_color):
    """Generate neumorphic CSS based on parameters"""
    
    # Convert hex to RGB for calculations
    bg_rgb = hex_to_rgb(bg_color)
    
    # Calculate light and dark shadow colors
    light_shadow = adjust_brightness(bg_rgb, intensity / 100 * 0.3)
    dark_shadow = adjust_brightness(bg_rgb, -intensity / 100 * 0.3)
    
    css = f"""
.neumorphic-element {{
    background: {bg_color};
    border-radius: {radius}px;
    box-shadow:
        {x_offset}px {y_offset}px {blur}px rgba({dark_shadow[0]}, {dark_shadow[1]}, {dark_shadow[2]}, 0.2),
        -{x_offset}px -{y_offset}px {blur}px rgba({light_shadow[0]}, {light_shadow[1]}, {light_shadow[2]}, 0.7);
    padding: 20px;
    margin: 20px;
    transition: all 0.3s ease;
}}

.neumorphic-element:hover {{
    box-shadow:
        {x_offset//2}px {y_offset//2}px {blur//2}px rgba({dark_shadow[0]}, {dark_shadow[1]}, {dark_shadow[2]}, 0.1),
        -{x_offset//2}px -{y_offset//2}px {blur//2}px rgba({light_shadow[0]}, {light_shadow[1]}, {light_shadow[2]}, 0.5);
}}

.neumorphic-pressed {{
    box-shadow:
        inset {x_offset//2}px {y_offset//2}px {blur//2}px rgba({dark_shadow[0]}, {dark_shadow[1]}, {dark_shadow[2]}, 0.2),
        inset -{x_offset//2}px -{y_offset//2}px {blur//2}px rgba({light_shadow[0]}, {light_shadow[1]}, {light_shadow[2]}, 0.7);
}}
"""
    
    return css.strip()

def hex_to_rgb(hex_color):
    """Convert hex color to RGB tuple"""
    hex_color = hex_color.lstrip('#')
    return tuple(int(hex_color[i:i+2], 16) for i in (0, 2, 4))

def adjust_brightness(rgb, factor):
    """Adjust RGB brightness by factor (-1 to 1)"""
    return tuple(max(0, min(255, int(c + c * factor))) for c in rgb)

@app.route('/save-design', methods=['POST'])
def save_design():
    """Save a design to the database"""
    try:
        data = request.get_json()
        
        design = Design()
        design.name = data.get('name', 'Untitled Design')
        design.x_offset = data.get('x_offset', 10)
        design.y_offset = data.get('y_offset', 10)
        design.radius = data.get('radius', 50)
        design.intensity = data.get('intensity', 50)
        design.blur = data.get('blur', 20)
        design.background_color = data.get('background_color', '#e0e0e0')
        design.shape = data.get('shape', 'rectangle')
        
        db.session.add(design)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'design': design.to_dict(),
            'message': 'Design saved successfully!'
        })
    
    except Exception as e:
        current_app.logger.error(f"Save design error: {str(e)}")
        db.session.rollback()
        return jsonify({'error': 'Failed to save design'}), 500

@app.route('/load-design/<int:design_id>', methods=['GET'])
def load_design(design_id):
    """Load a design from the database"""
    try:
        design = Design.query.get_or_404(design_id)
        return jsonify({
            'success': True,
            'design': design.to_dict()
        })
    
    except Exception as e:
        current_app.logger.error(f"Load design error: {str(e)}")
        return jsonify({'error': 'Failed to load design'}), 500

@app.route('/designs', methods=['GET'])
def get_designs():
    """Get all saved designs"""
    try:
        designs = Design.query.order_by(Design.created_at.desc()).all()
        return jsonify({
            'success': True,
            'designs': [design.to_dict() for design in designs]
        })
    
    except Exception as e:
        current_app.logger.error(f"Get designs error: {str(e)}")
        return jsonify({'error': 'Failed to fetch designs'}), 500

@app.route('/delete-design/<int:design_id>', methods=['DELETE'])
def delete_design(design_id):
    """Delete a design from the database"""
    try:
        design = Design.query.get_or_404(design_id)
        db.session.delete(design)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Design deleted successfully!'
        })
    
    except Exception as e:
        current_app.logger.error(f"Delete design error: {str(e)}")
        db.session.rollback()
        return jsonify({'error': 'Failed to delete design'}), 500

@app.errorhandler(413)
def too_large(e):
    return jsonify({'error': 'File too large. Maximum size is 5MB.'}), 413
