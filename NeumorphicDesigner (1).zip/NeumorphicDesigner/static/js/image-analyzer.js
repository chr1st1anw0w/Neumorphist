// Image Analysis Module for Neumorphism Tool

class ImageAnalyzer {
    constructor() {
        this.canvas = document.createElement('canvas');
        this.ctx = this.canvas.getContext('2d');
    }
    
    /**
     * Analyze an image file and extract color and shadow information
     * @param {File} imageFile - The image file to analyze
     * @returns {Promise<Object>} Analysis results
     */
    async analyzeImage(imageFile) {
        return new Promise((resolve, reject) => {
            const img = new Image();
            const reader = new FileReader();
            
            reader.onload = (e) => {
                img.onload = () => {
                    try {
                        const analysis = this.processImage(img);
                        resolve(analysis);
                    } catch (error) {
                        reject(error);
                    }
                };
                
                img.onerror = () => {
                    reject(new Error('Failed to load image'));
                };
                
                img.src = e.target.result;
            };
            
            reader.onerror = () => {
                reject(new Error('Failed to read file'));
            };
            
            reader.readAsDataURL(imageFile);
        });
    }
    
    /**
     * Process the loaded image and extract neumorphic parameters
     * @param {HTMLImageElement} img - The loaded image element
     * @returns {Object} Analysis results
     */
    processImage(img) {
        // Set canvas size (limit for performance)
        const maxSize = 200;
        const scale = Math.min(maxSize / img.width, maxSize / img.height);
        this.canvas.width = img.width * scale;
        this.canvas.height = img.height * scale;
        
        // Draw image to canvas
        this.ctx.drawImage(img, 0, 0, this.canvas.width, this.canvas.height);
        
        // Get image data
        const imageData = this.ctx.getImageData(0, 0, this.canvas.width, this.canvas.height);
        const pixels = imageData.data;
        
        // Analyze colors and lighting
        const colorAnalysis = this.analyzeColors(pixels);
        const lightingAnalysis = this.analyzeLighting(pixels);
        const edgeAnalysis = this.analyzeEdges(imageData);
        
        // Calculate suggested parameters
        const suggestedParams = this.calculateParameters(colorAnalysis, lightingAnalysis, edgeAnalysis);
        
        return {
            dominantColors: colorAnalysis.dominantColors,
            brightness: lightingAnalysis.averageBrightness,
            contrast: lightingAnalysis.contrast,
            shadowInfo: lightingAnalysis.shadowInfo,
            suggestedParameters: suggestedParams
        };
    }
    
    /**
     * Analyze color distribution in the image
     * @param {Uint8ClampedArray} pixels - Pixel data
     * @returns {Object} Color analysis results
     */
    analyzeColors(pixels) {
        const colorMap = new Map();
        const totalPixels = pixels.length / 4;
        
        // Sample every 4th pixel for performance
        for (let i = 0; i < pixels.length; i += 16) {
            const r = pixels[i];
            const g = pixels[i + 1];
            const b = pixels[i + 2];
            const a = pixels[i + 3];
            
            // Skip transparent pixels
            if (a < 128) continue;
            
            // Group similar colors (reduce precision)
            const key = `${Math.floor(r/8)*8},${Math.floor(g/8)*8},${Math.floor(b/8)*8}`;
            
            if (colorMap.has(key)) {
                colorMap.set(key, colorMap.get(key) + 1);
            } else {
                colorMap.set(key, 1);
            }
        }
        
        // Sort colors by frequency
        const sortedColors = Array.from(colorMap.entries())
            .sort((a, b) => b[1] - a[1])
            .slice(0, 5);
        
        const dominantColors = sortedColors.map(([color, count]) => {
            const [r, g, b] = color.split(',').map(Number);
            return this.rgbToHex(r, g, b);
        });
        
        return {
            dominantColors,
            colorDistribution: sortedColors
        };
    }
    
    /**
     * Analyze lighting and shadows in the image
     * @param {Uint8ClampedArray} pixels - Pixel data
     * @returns {Object} Lighting analysis results
     */
    analyzeLighting(pixels) {
        let totalBrightness = 0;
        let brightnesses = [];
        let validPixels = 0;
        
        for (let i = 0; i < pixels.length; i += 4) {
            const r = pixels[i];
            const g = pixels[i + 1];
            const b = pixels[i + 2];
            const a = pixels[i + 3];
            
            // Skip transparent pixels
            if (a < 128) continue;
            
            // Calculate perceived brightness
            const brightness = (r * 0.299 + g * 0.587 + b * 0.114);
            totalBrightness += brightness;
            brightnesses.push(brightness);
            validPixels++;
        }
        
        const averageBrightness = totalBrightness / validPixels;
        
        // Calculate standard deviation for contrast
        const variance = brightnesses.reduce((sum, b) => {
            return sum + Math.pow(b - averageBrightness, 2);
        }, 0) / validPixels;
        
        const stdDev = Math.sqrt(variance);
        const contrast = stdDev / 128; // Normalize to 0-1
        
        // Analyze shadow distribution
        const darkPixels = brightnesses.filter(b => b < averageBrightness * 0.7).length;
        const lightPixels = brightnesses.filter(b => b > averageBrightness * 1.3).length;
        
        const shadowInfo = {
            hasShadows: darkPixels / validPixels > 0.2,
            hasHighlights: lightPixels / validPixels > 0.2,
            shadowStrength: darkPixels / validPixels,
            highlightStrength: lightPixels / validPixels
        };
        
        return {
            averageBrightness: averageBrightness / 255, // Normalize to 0-1
            contrast,
            shadowInfo
        };
    }
    
    /**
     * Analyze edges and shapes in the image
     * @param {ImageData} imageData - Canvas image data
     * @returns {Object} Edge analysis results
     */
    analyzeEdges(imageData) {
        const { width, height, data } = imageData;
        let edgeCount = 0;
        let totalEdges = 0;
        
        // Simple edge detection using brightness differences
        for (let y = 1; y < height - 1; y++) {
            for (let x = 1; x < width - 1; x++) {
                const centerIdx = (y * width + x) * 4;
                const centerBrightness = this.getPixelBrightness(data, centerIdx);
                
                // Check adjacent pixels
                const neighbors = [
                    this.getPixelBrightness(data, ((y-1) * width + x) * 4),
                    this.getPixelBrightness(data, ((y+1) * width + x) * 4),
                    this.getPixelBrightness(data, (y * width + (x-1)) * 4),
                    this.getPixelBrightness(data, (y * width + (x+1)) * 4)
                ];
                
                const maxDiff = Math.max(...neighbors.map(n => Math.abs(n - centerBrightness)));
                
                if (maxDiff > 30) { // Edge threshold
                    edgeCount++;
                }
                totalEdges++;
            }
        }
        
        const edgeDensity = edgeCount / totalEdges;
        
        return {
            edgeDensity,
            hasSharpEdges: edgeDensity > 0.1,
            hasSoftEdges: edgeDensity < 0.05
        };
    }
    
    /**
     * Calculate suggested neumorphic parameters based on analysis
     * @param {Object} colorAnalysis - Color analysis results
     * @param {Object} lightingAnalysis - Lighting analysis results
     * @param {Object} edgeAnalysis - Edge analysis results
     * @returns {Object} Suggested parameters
     */
    calculateParameters(colorAnalysis, lightingAnalysis, edgeAnalysis) {
        const { dominantColors } = colorAnalysis;
        const { averageBrightness, contrast, shadowInfo } = lightingAnalysis;
        const { edgeDensity, hasSharpEdges } = edgeAnalysis;
        
        // Base parameters
        let xOffset = 10;
        let yOffset = 10;
        let radius = 50;
        let intensity = 50;
        let blur = 20;
        
        // Adjust based on image characteristics
        if (contrast > 0.5) {
            // High contrast image - reduce intensity
            intensity = Math.max(30, intensity - 20);
            blur = Math.min(35, blur + 10);
        }
        
        if (shadowInfo.hasShadows) {
            // Image has existing shadows - enhance them
            xOffset = Math.min(20, xOffset + 5);
            yOffset = Math.min(20, yOffset + 5);
            intensity = Math.min(80, intensity + 15);
        }
        
        if (hasSharpEdges) {
            // Sharp edges suggest flat design
            radius = Math.max(10, radius - 20);
            blur = Math.max(10, blur - 5);
        } else {
            // Soft edges suggest rounded design
            radius = Math.min(80, radius + 15);
            blur = Math.min(30, blur + 5);
        }
        
        // Adjust for brightness
        if (averageBrightness < 0.3) {
            // Dark image - lighten background
            intensity = Math.min(70, intensity + 20);
        } else if (averageBrightness > 0.8) {
            // Very bright image - reduce intensity
            intensity = Math.max(20, intensity - 15);
        }
        
        // Choose best background color
        let backgroundColor = '#e0e0e0';
        if (dominantColors.length > 0) {
            // Find the lightest suitable color
            const lightColors = dominantColors.filter(color => {
                const rgb = this.hexToRgb(color);
                const brightness = (rgb[0] + rgb[1] + rgb[2]) / 3;
                return brightness > 150; // Ensure it's light enough for neumorphism
            });
            
            if (lightColors.length > 0) {
                backgroundColor = lightColors[0];
            } else {
                // Lighten the most dominant color
                const rgb = this.hexToRgb(dominantColors[0]);
                const lightened = rgb.map(c => Math.min(255, c + (255 - c) * 0.5));
                backgroundColor = this.rgbToHex(...lightened);
            }
        }
        
        return {
            xOffset: Math.round(xOffset),
            yOffset: Math.round(yOffset),
            radius: Math.round(radius),
            intensity: Math.round(intensity),
            blur: Math.round(blur),
            backgroundColor
        };
    }
    
    /**
     * Get pixel brightness from pixel data
     * @param {Uint8ClampedArray} data - Pixel data
     * @param {number} index - Pixel index
     * @returns {number} Brightness value
     */
    getPixelBrightness(data, index) {
        const r = data[index];
        const g = data[index + 1];
        const b = data[index + 2];
        return r * 0.299 + g * 0.587 + b * 0.114;
    }
    
    /**
     * Convert RGB to hex
     * @param {number} r - Red value
     * @param {number} g - Green value
     * @param {number} b - Blue value
     * @returns {string} Hex color string
     */
    rgbToHex(r, g, b) {
        return '#' + [r, g, b].map(x => {
            const hex = Math.round(x).toString(16);
            return hex.length === 1 ? '0' + hex : hex;
        }).join('');
    }
    
    /**
     * Convert hex to RGB
     * @param {string} hex - Hex color string
     * @returns {Array<number>} RGB values
     */
    hexToRgb(hex) {
        const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
        return result ? [
            parseInt(result[1], 16),
            parseInt(result[2], 16),
            parseInt(result[3], 16)
        ] : [224, 224, 224];
    }
}

// Export for use in main.js
window.ImageAnalyzer = ImageAnalyzer;
