class NeumorphistTool {
    constructor() {
        this.parameters = {
            xOffset: 10,
            yOffset: 10,
            radius: 50,
            intensity: 50,
            blur: 20,
            backgroundColor: '#e0e0e0'
        };
        
        this.currentShape = 'rectangle';
        
        this.presets = {
            soft: { xOffset: 5, yOffset: 5, radius: 25, intensity: 30, blur: 15 },
            deep: { xOffset: 15, yOffset: 15, radius: 35, intensity: 70, blur: 25 },
            flat: { xOffset: 3, yOffset: 3, radius: 50, intensity: 20, blur: 8 },
            pressed: { xOffset: 8, yOffset: 8, radius: 25, intensity: 80, blur: 20 }
        };
        
        this.init();
        this.loadSavedDesigns();
    }
    
    init() {
        this.setupEventListeners();
        this.updatePreview();
        this.generateCSS();
    }
    
    setupEventListeners() {
        // Parameter sliders
        ['xOffset', 'yOffset', 'radius', 'intensity', 'blur'].forEach(param => {
            const slider = document.getElementById(param);
            const valueDisplay = document.getElementById(param + 'Value');
            
            if (slider && valueDisplay) {
                slider.addEventListener('input', (e) => {
                    this.parameters[param] = parseInt(e.target.value);
                    valueDisplay.textContent = e.target.value;
                    this.updatePreview();
                    this.generateCSS();
                });
            }
        });

        // Color picker
        const colorPicker = document.getElementById('colorPicker');
        const colorHex = document.getElementById('colorHex');
        
        if (colorPicker) {
            colorPicker.addEventListener('input', (e) => {
                this.parameters.backgroundColor = e.target.value;
                if (colorHex) colorHex.value = e.target.value;
                this.updatePreview();
                this.generateCSS();
            });
        }
        
        if (colorHex) {
            colorHex.addEventListener('input', (e) => {
                if (/^#[0-9A-F]{6}$/i.test(e.target.value)) {
                    this.parameters.backgroundColor = e.target.value;
                    if (colorPicker) colorPicker.value = e.target.value;
                    this.updatePreview();
                    this.generateCSS();
                }
            });
        }

        // Shape buttons
        document.querySelectorAll('.shape-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                document.querySelectorAll('.shape-btn').forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
                this.currentShape = btn.dataset.shape;
                this.updatePreview();
                this.generateCSS();
            });
        });

        // Preset buttons
        document.querySelectorAll('.preset-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                this.applyPreset(btn.dataset.preset);
            });
        });

        // Export buttons
        const copyBtn = document.getElementById('copyBtn');
        if (copyBtn) {
            copyBtn.addEventListener('click', () => {
                this.copyCSS();
            });
        }

        const exportSvgBtn = document.getElementById('exportSvg');
        if (exportSvgBtn) {
            exportSvgBtn.addEventListener('click', () => {
                this.exportSVG();
            });
        }

        const exportPngBtn = document.getElementById('exportPng');
        if (exportPngBtn) {
            exportPngBtn.addEventListener('click', () => {
                this.exportPNG();
            });
        }

        // Save design button
        const saveBtn = document.getElementById('saveBtn');
        if (saveBtn) {
            saveBtn.addEventListener('click', () => {
                this.saveDesign();
            });
        }
    }
    
    updatePreview() {
        const preview = document.getElementById('preview');
        if (!preview) return;

        const { xOffset, yOffset, radius, intensity, blur, backgroundColor } = this.parameters;
        
        // Calculate shadow colors
        const rgb = this.hexToRgb(backgroundColor);
        const lightShadow = this.adjustBrightness(rgb, intensity / 100);
        const darkShadow = this.adjustBrightness(rgb, -intensity / 100);
        
        const lightColor = `rgb(${lightShadow.join(',')})`;
        const darkColor = `rgb(${darkShadow.join(',')})`;
        
        // Apply styles to preview element
        preview.style.background = backgroundColor;
        preview.style.borderRadius = `${radius}px`;
        preview.style.boxShadow = `${xOffset}px ${yOffset}px ${blur}px ${darkColor}, -${xOffset}px -${yOffset}px ${blur}px ${lightColor}`;
        
        // Update preview shape
        if (this.currentShape === 'circle') {
            preview.style.borderRadius = '50%';
        }
    }
    
    generateCSS() {
        const { xOffset, yOffset, radius, intensity, blur, backgroundColor } = this.parameters;
        
        const rgb = this.hexToRgb(backgroundColor);
        const lightShadow = this.adjustBrightness(rgb, intensity / 100);
        const darkShadow = this.adjustBrightness(rgb, -intensity / 100);
        
        const lightColor = `rgb(${lightShadow.join(',')})`;
        const darkColor = `rgb(${darkShadow.join(',')})`;
        
        const borderRadiusValue = this.currentShape === 'circle' ? '50%' : `${radius}px`;
        
        const css = `.neumorphic-button {
  background: ${backgroundColor};
  border-radius: ${borderRadiusValue};
  box-shadow: ${xOffset}px ${yOffset}px ${blur}px ${darkColor}, -${xOffset}px -${yOffset}px ${blur}px ${lightColor};
  border: none;
  padding: 20px 40px;
  cursor: pointer;
  transition: all 0.3s ease;
}

.neumorphic-button:hover {
  box-shadow: ${Math.round(xOffset * 0.5)}px ${Math.round(yOffset * 0.5)}px ${Math.round(blur * 0.8)}px ${darkColor}, -${Math.round(xOffset * 0.5)}px -${Math.round(yOffset * 0.5)}px ${Math.round(blur * 0.8)}px ${lightColor};
}

.neumorphic-button:active {
  box-shadow: inset ${Math.round(xOffset * 0.5)}px ${Math.round(yOffset * 0.5)}px ${Math.round(blur * 0.5)}px ${darkColor}, inset -${Math.round(xOffset * 0.5)}px -${Math.round(yOffset * 0.5)}px ${Math.round(blur * 0.5)}px ${lightColor};
}`;

        const codeOutput = document.getElementById('codeOutput');
        if (codeOutput) {
            codeOutput.textContent = css;
            // Trigger syntax highlighting if Prism is available
            if (typeof Prism !== 'undefined') {
                Prism.highlightElement(codeOutput);
            }
        }
        
        return css;
    }
    
    applyPreset(presetName) {
        const preset = this.presets[presetName];
        if (!preset) return;

        // Update parameters
        Object.assign(this.parameters, preset);

        // Update UI controls
        Object.keys(preset).forEach(key => {
            const slider = document.getElementById(key);
            const valueDisplay = document.getElementById(key + 'Value');
            
            if (slider) slider.value = preset[key];
            if (valueDisplay) valueDisplay.textContent = preset[key];
        });

        this.updatePreview();
        this.generateCSS();
    }
    
    copyCSS() {
        const css = this.generateCSS();
        
        if (navigator.clipboard && window.isSecureContext) {
            navigator.clipboard.writeText(css).then(() => {
                this.showNotification('CSS copied to clipboard!', 'success');
            }).catch(() => {
                this.fallbackCopyTextToClipboard(css);
            });
        } else {
            this.fallbackCopyTextToClipboard(css);
        }
    }
    
    fallbackCopyTextToClipboard(text) {
        const textArea = document.createElement('textarea');
        textArea.value = text;
        textArea.style.position = 'fixed';
        textArea.style.left = '-999999px';
        textArea.style.top = '-999999px';
        document.body.appendChild(textArea);
        textArea.focus();
        textArea.select();
        
        try {
            document.execCommand('copy');
            this.showNotification('CSS copied to clipboard!', 'success');
        } catch (err) {
            this.showNotification('Failed to copy CSS', 'error');
        }
        
        document.body.removeChild(textArea);
    }
    
    exportSVG() {
        const { xOffset, yOffset, radius, intensity, blur, backgroundColor } = this.parameters;
        const rgb = this.hexToRgb(backgroundColor);
        const lightShadow = this.adjustBrightness(rgb, intensity / 100);
        const darkShadow = this.adjustBrightness(rgb, -intensity / 100);
        
        const lightColor = `rgb(${lightShadow.join(',')})`;
        const darkColor = `rgb(${darkShadow.join(',')})`;
        
        const svgContent = `<svg width="200" height="100" xmlns="http://www.w3.org/2000/svg">
  <defs>
    <filter id="neumorphism" x="-50%" y="-50%" width="200%" height="200%">
      <feDropShadow dx="${xOffset}" dy="${yOffset}" stdDeviation="${blur/2}" flood-color="${darkColor}" flood-opacity="1"/>
      <feDropShadow dx="-${xOffset}" dy="-${yOffset}" stdDeviation="${blur/2}" flood-color="${lightColor}" flood-opacity="1"/>
    </filter>
  </defs>
  <rect x="50" y="25" width="100" height="50" rx="${radius}" fill="${backgroundColor}" filter="url(#neumorphism)"/>
</svg>`;

        this.downloadFile(svgContent, 'neumorphic-button.svg', 'image/svg+xml');
    }
    
    exportPNG() {
        const canvas = document.createElement('canvas');
        canvas.width = 300;
        canvas.height = 200;
        const ctx = canvas.getContext('2d');
        
        const { xOffset, yOffset, radius, intensity, blur, backgroundColor } = this.parameters;
        
        // Fill background
        ctx.fillStyle = backgroundColor;
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        
        // Draw neumorphic button
        const buttonX = 100;
        const buttonY = 75;
        const buttonWidth = 100;
        const buttonHeight = 50;
        
        ctx.fillStyle = backgroundColor;
        ctx.beginPath();
        if (this.currentShape === 'circle') {
            ctx.arc(buttonX + buttonWidth/2, buttonY + buttonHeight/2, Math.min(buttonWidth, buttonHeight)/2, 0, 2 * Math.PI);
        } else {
            ctx.roundRect(buttonX, buttonY, buttonWidth, buttonHeight, radius);
        }
        ctx.fill();
        
        canvas.toBlob((blob) => {
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = 'neumorphic-button.png';
            a.click();
            URL.revokeObjectURL(url);
        });
    }
    
    downloadFile(content, filename, mimeType) {
        const blob = new Blob([content], { type: mimeType });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = filename;
        a.click();
        URL.revokeObjectURL(url);
    }
    
    showNotification(message, type = 'info') {
        const notification = document.createElement('div');
        notification.className = `alert alert-${type === 'success' ? 'success' : 'danger'} position-fixed`;
        notification.style.top = '20px';
        notification.style.right = '20px';
        notification.style.zIndex = '9999';
        notification.textContent = message;
        
        document.body.appendChild(notification);
        
        setTimeout(() => {
            if (notification.parentNode) {
                notification.parentNode.removeChild(notification);
            }
        }, 3000);
    }
    
    hexToRgb(hex) {
        const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
        return result ? [
            parseInt(result[1], 16),
            parseInt(result[2], 16),
            parseInt(result[3], 16)
        ] : [224, 224, 224];
    }
    
    adjustBrightness(rgb, factor) {
        return rgb.map(c => Math.max(0, Math.min(255, Math.round(c + c * factor))));
    }

    async saveDesign() {
        const name = prompt('Enter a name for this design:');
        if (!name) return;

        const designData = {
            name: name,
            x_offset: this.parameters.xOffset,
            y_offset: this.parameters.yOffset,
            radius: this.parameters.radius,
            intensity: this.parameters.intensity,
            blur: this.parameters.blur,
            background_color: this.parameters.backgroundColor,
            shape: this.currentShape
        };

        try {
            const response = await fetch('/save-design', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(designData)
            });

            const result = await response.json();

            if (result.success) {
                this.showNotification('Design saved successfully!', 'success');
                this.loadSavedDesigns();
            } else {
                this.showNotification(result.error || 'Failed to save design', 'error');
            }
        } catch (error) {
            console.error('Save error:', error);
            this.showNotification('Failed to save design', 'error');
        }
    }

    async loadSavedDesigns() {
        try {
            const response = await fetch('/designs');
            const result = await response.json();

            if (result.success) {
                this.displaySavedDesigns(result.designs);
            }
        } catch (error) {
            console.error('Load designs error:', error);
        }
    }

    displaySavedDesigns(designs) {
        const container = document.getElementById('savedDesigns');
        if (!container) return;

        if (designs.length === 0) {
            container.innerHTML = '<p class="text-muted text-center">No saved designs yet</p>';
            return;
        }

        container.innerHTML = designs.map(design => `
            <div class="design-item" data-id="${design.id}">
                <div class="design-preview" style="background: ${design.background_color}; border-radius: ${design.radius}px; box-shadow: ${design.x_offset}px ${design.y_offset}px ${design.blur}px rgba(0,0,0,0.2), -${design.x_offset}px -${design.y_offset}px ${design.blur}px rgba(255,255,255,0.7);"></div>
                <div class="design-info">
                    <p class="design-name">${design.name}</p>
                    <p class="design-date">${new Date(design.created_at).toLocaleDateString()}</p>
                </div>
                <div class="design-actions">
                    <button class="design-delete" onclick="tool.deleteDesign(${design.id})" title="Delete">×</button>
                </div>
            </div>
        `).join('');

        // Add click listeners to load designs
        container.querySelectorAll('.design-item').forEach(item => {
            item.addEventListener('click', (e) => {
                if (!e.target.classList.contains('design-delete')) {
                    this.loadDesign(parseInt(item.dataset.id));
                }
            });
        });
    }

    async loadDesign(designId) {
        try {
            const response = await fetch(`/load-design/${designId}`);
            const result = await response.json();

            if (result.success) {
                const design = result.design;
                
                // Update parameters
                Object.assign(this.parameters, {
                    xOffset: design.x_offset,
                    yOffset: design.y_offset,
                    radius: design.radius,
                    intensity: design.intensity,
                    blur: design.blur,
                    backgroundColor: design.background_color
                });

                this.currentShape = design.shape;

                // Update UI controls
                Object.keys(this.parameters).forEach(key => {
                    const slider = document.getElementById(key);
                    const valueDisplay = document.getElementById(key + 'Value');
                    
                    if (slider && key !== 'backgroundColor') {
                        slider.value = this.parameters[key];
                    }
                    if (valueDisplay && key !== 'backgroundColor') {
                        valueDisplay.textContent = this.parameters[key];
                    }
                });

                // Update color picker
                const colorPicker = document.getElementById('colorPicker');
                const colorHex = document.getElementById('colorHex');
                if (colorPicker) colorPicker.value = this.parameters.backgroundColor;
                if (colorHex) colorHex.value = this.parameters.backgroundColor;

                // Update shape selector
                document.querySelectorAll('.shape-btn').forEach(btn => {
                    btn.classList.toggle('active', btn.dataset.shape === this.currentShape);
                });

                this.updatePreview();
                this.generateCSS();
                this.showNotification('Design loaded successfully!', 'success');
            } else {
                this.showNotification(result.error || 'Failed to load design', 'error');
            }
        } catch (error) {
            console.error('Load design error:', error);
            this.showNotification('Failed to load design', 'error');
        }
    }

    async deleteDesign(designId) {
        if (!confirm('Are you sure you want to delete this design?')) {
            return;
        }

        try {
            const response = await fetch(`/delete-design/${designId}`, {
                method: 'DELETE'
            });

            const result = await response.json();

            if (result.success) {
                this.showNotification('Design deleted successfully!', 'success');
                this.loadSavedDesigns();
            } else {
                this.showNotification(result.error || 'Failed to delete design', 'error');
            }
        } catch (error) {
            console.error('Delete design error:', error);
            this.showNotification('Failed to delete design', 'error');
        }
    }
}

// Canvas roundRect polyfill for older browsers
if (!CanvasRenderingContext2D.prototype.roundRect) {
    CanvasRenderingContext2D.prototype.roundRect = function (x, y, w, h, r) {
        if (w < 2 * r) r = w / 2;
        if (h < 2 * r) r = h / 2;
        this.beginPath();
        this.moveTo(x + r, y);
        this.arcTo(x + w, y, x + w, y + h, r);
        this.arcTo(x + w, y + h, x, y + h, r);
        this.arcTo(x, y + h, x, y, r);
        this.arcTo(x, y, x + w, y, r);
        this.closePath();
        return this;
    };
}

// Global tool variable for design deletion
let tool;

// Initialize the tool when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    tool = new NeumorphistTool();
});