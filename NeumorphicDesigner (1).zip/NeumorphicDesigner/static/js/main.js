// Neumorphism Design Tool - Main JavaScript

class NeumorphismTool {
    constructor() {
        this.parameters = {
            xOffset: 10,
            yOffset: 10,
            radius: 50,
            intensity: 50,
            blur: 20,
            backgroundColor: '#e0e0e0',
            lightShadowColor: '#ffffff',
            darkShadowColor: '#bebebe',
            buttonColor: '#f0f0f0'
        };
        
        this.shadowTypes = {
            dropShadow: true,
            innerShadow: false,
            multipleDropShadows: false,
            multipleInnerShadows: false
        };
        
        this.additionalShadows = [];
        
        this.currentShape = 'rectangle';
        this.currentCodeType = 'css';
        this.presets = {
            soft: { xOffset: 5, yOffset: 5, radius: 30, intensity: 30, blur: 15 },
            deep: { xOffset: 15, yOffset: 15, radius: 20, intensity: 70, blur: 30 },
            flat: { xOffset: 3, yOffset: 3, radius: 50, intensity: 20, blur: 8 },
            pressed: { xOffset: 8, yOffset: 8, radius: 25, intensity: 80, blur: 20 }
        };
        
        this.init();
        this.loadSavedDesigns();
    }
    
    init() {
        this.setupEventListeners();
        this.updatePreview();
        this.generateCSS();
        
        // Initialize Prism for syntax highlighting
        if (typeof Prism !== 'undefined') {
            Prism.highlightAll();
        }
    }
    
    setupEventListeners() {
        // Slider inputs
        const sliders = ['xOffset', 'yOffset', 'radius', 'intensity', 'blur'];
        sliders.forEach(param => {
            const slider = document.getElementById(param);
            const valueDisplay = document.getElementById(param + 'Value');
            
            if (slider && valueDisplay) {
                slider.addEventListener('input', (e) => {
                    const value = parseInt(e.target.value);
                    this.parameters[param] = value;
                    valueDisplay.textContent = value;
                    this.updatePreview();
                    this.generateCode();
                });
            }
        });
        
        // Color inputs
        const colorInputs = ['backgroundColor', 'lightShadowColor', 'darkShadowColor', 'buttonColor'];
        colorInputs.forEach(param => {
            const colorInput = document.getElementById(param);
            if (colorInput) {
                colorInput.addEventListener('input', (e) => {
                    this.parameters[param] = e.target.value;
                    this.updatePreview();
                    this.generateCode();
                });
            }
        });
        
        // Shadow type checkboxes
        const shadowCheckboxes = ['dropShadow', 'innerShadow', 'multipleDropShadows', 'multipleInnerShadows'];
        shadowCheckboxes.forEach(type => {
            const checkbox = document.getElementById(type);
            if (checkbox) {
                checkbox.addEventListener('change', (e) => {
                    this.shadowTypes[type] = e.target.checked;
                    this.updatePreview();
                    this.generateCode();
                });
            }
        });
                    this.parameters[param] = value;
                    valueDisplay.textContent = value;
                    this.updatePreview();
                    this.generateCSS();
                });
            }
        });
        
        // Color picker
        const colorPicker = document.getElementById('colorPicker');
        const colorHex = document.getElementById('colorHex');
        
        if (colorPicker && colorHex) {
            colorPicker.addEventListener('input', (e) => {
                this.parameters.backgroundColor = e.target.value;
                colorHex.value = e.target.value;
                this.updatePreview();
                this.generateCSS();
            });
            
            colorHex.addEventListener('input', (e) => {
                const value = e.target.value;
                if (/^#[0-9A-F]{6}$/i.test(value)) {
                    this.parameters.backgroundColor = value;
                    colorPicker.value = value;
                    this.updatePreview();
                    this.generateCSS();
                }
            });
        }
        
        // Shape selector
        const shapeButtons = document.querySelectorAll('.shape-btn');
        shapeButtons.forEach(btn => {
            btn.addEventListener('click', (e) => {
                shapeButtons.forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
                this.currentShape = btn.dataset.shape;
                this.updatePreview();
            });
        });
        
        // Preset buttons
        const presetButtons = document.querySelectorAll('.preset-btn');
        presetButtons.forEach(btn => {
            btn.addEventListener('click', (e) => {
                const preset = this.presets[btn.dataset.preset];
                if (preset) {
                    this.applyPreset(preset);
                }
            });
        });
        
        // Export buttons
        document.getElementById('copyBtn')?.addEventListener('click', () => {
            this.copyCSS();
        });

        // Save design button
        document.getElementById('saveBtn')?.addEventListener('click', () => {
            this.saveDesign();
        });
        
        document.getElementById('exportSvg')?.addEventListener('click', () => {
            this.exportSVG();
        });
        
        document.getElementById('exportPng')?.addEventListener('click', () => {
            this.exportPNG();
        });
        
        // Upload area
        const uploadArea = document.getElementById('uploadArea');
        const fileInput = document.getElementById('imageUpload');
        
        if (uploadArea && fileInput) {
            uploadArea.addEventListener('click', () => fileInput.click());
            
            uploadArea.addEventListener('dragover', (e) => {
                e.preventDefault();
                uploadArea.classList.add('dragover');
            });
            
            uploadArea.addEventListener('dragleave', () => {
                uploadArea.classList.remove('dragover');
            });
            
            uploadArea.addEventListener('drop', (e) => {
                e.preventDefault();
                uploadArea.classList.remove('dragover');
                const files = e.dataTransfer.files;
                if (files.length > 0) {
                    this.handleFileUpload(files[0]);
                }
            });
            
            fileInput.addEventListener('change', (e) => {
                if (e.target.files.length > 0) {
                    this.handleFileUpload(e.target.files[0]);
                }
            });
        }
    }
    
    updatePreview() {
        const previewElement = document.getElementById('previewElement');
        if (!previewElement) return;
        
        const { xOffset, yOffset, radius, intensity, blur, backgroundColor } = this.parameters;
        
        // Calculate shadow colors
        const bgRgb = this.hexToRgb(backgroundColor);
        const lightShadow = this.adjustBrightness(bgRgb, intensity / 100 * 0.3);
        const darkShadow = this.adjustBrightness(bgRgb, -intensity / 100 * 0.3);
        
        // Apply styles
        previewElement.style.background = backgroundColor;
        previewElement.style.boxShadow = `
            ${xOffset}px ${yOffset}px ${blur}px rgba(${darkShadow.join(',')}, 0.2),
            -${xOffset}px -${yOffset}px ${blur}px rgba(${lightShadow.join(',')}, 0.7)
        `;
        
        // Apply shape-specific styles
        previewElement.className = `preview-element ${this.currentShape}`;
        
        if (this.currentShape === 'rectangle') {
            previewElement.style.borderRadius = `${radius}px`;
        } else if (this.currentShape === 'circle') {
            previewElement.style.borderRadius = '50%';
        } else if (this.currentShape === 'button') {
            previewElement.style.borderRadius = '25px';
        }
        
        // Update document background
        document.body.style.backgroundColor = backgroundColor;
        document.documentElement.style.setProperty('--background', backgroundColor);
        document.documentElement.style.setProperty('--surface', backgroundColor);
    }
    
    generateCSS() {
        const { xOffset, yOffset, radius, intensity, blur, backgroundColor, lightShadowColor, darkShadowColor, buttonColor } = this.parameters;
        
        const lightShadowRgb = this.hexToRgb(lightShadowColor);
        const darkShadowRgb = this.hexToRgb(darkShadowColor);
        
        let shadows = [];
        
        // Main drop shadow
        if (this.shadowTypes.dropShadow) {
            shadows.push(`${xOffset}px ${yOffset}px ${blur}px rgba(${darkShadowRgb.join(',')}, 0.2)`);
            shadows.push(`-${xOffset}px -${yOffset}px ${blur}px rgba(${lightShadowRgb.join(',')}, 0.7)`);
        }
        
        // Multiple drop shadows
        if (this.shadowTypes.multipleDropShadows) {
            shadows.push(`${xOffset * 2}px ${yOffset * 2}px ${blur * 1.5}px rgba(${darkShadowRgb.join(',')}, 0.1)`);
            shadows.push(`-${xOffset * 2}px -${yOffset * 2}px ${blur * 1.5}px rgba(${lightShadowRgb.join(',')}, 0.5)`);
        }
        
        let innerShadows = [];
        
        // Inner shadow
        if (this.shadowTypes.innerShadow) {
            innerShadows.push(`inset ${xOffset}px ${yOffset}px ${blur}px rgba(${darkShadowRgb.join(',')}, 0.2)`);
            innerShadows.push(`inset -${xOffset}px -${yOffset}px ${blur}px rgba(${lightShadowRgb.join(',')}, 0.7)`);
        }
        
        // Multiple inner shadows
        if (this.shadowTypes.multipleInnerShadows) {
            innerShadows.push(`inset ${xOffset * 0.5}px ${yOffset * 0.5}px ${blur * 0.5}px rgba(${darkShadowRgb.join(',')}, 0.3)`);
            innerShadows.push(`inset -${xOffset * 0.5}px -${yOffset * 0.5}px ${blur * 0.5}px rgba(${lightShadowRgb.join(',')}, 0.8)`);
        }
        
        // Additional custom shadows
        this.additionalShadows.forEach(shadow => {
            const shadowRgb = this.hexToRgb(shadow.color);
            const shadowStr = `${shadow.type === 'inner' ? 'inset ' : ''}${shadow.xOffset}px ${shadow.yOffset}px ${shadow.blur}px rgba(${shadowRgb.join(',')}, ${shadow.opacity})`;
            if (shadow.type === 'inner') {
                innerShadows.push(shadowStr);
            } else {
                shadows.push(shadowStr);
            }
        });
        
        const allShadows = [...shadows, ...innerShadows].join(',\n        ');
        
        let css = `.neumorphic-element {
    background: ${backgroundColor};
    border-radius: ${radius}px;
    box-shadow: ${allShadows};
    padding: 20px;
    margin: 20px;
    transition: all 0.3s ease;
}

.neumorphic-button {
    background: ${buttonColor};
    border-radius: ${radius}px;
    box-shadow: ${allShadows};
    border: none;
    padding: 12px 24px;
    cursor: pointer;
    transition: all 0.3s ease;
}

.neumorphic-button:hover {
    box-shadow: ${shadows.map(s => s.replace(/0\.\d+\)/g, m => (parseFloat(m.slice(0, -1)) * 0.7) + ')')).join(',\n        ')};
}

.neumorphic-element:hover {
    box-shadow:
        ${Math.round(xOffset/2)}px ${Math.round(yOffset/2)}px ${Math.round(blur/2)}px rgba(${darkShadow.join(',')}, 0.1),
        -${Math.round(xOffset/2)}px -${Math.round(yOffset/2)}px ${Math.round(blur/2)}px rgba(${lightShadow.join(',')}, 0.5);
}

.neumorphic-pressed {
    box-shadow:
        inset ${Math.round(xOffset/2)}px ${Math.round(yOffset/2)}px ${Math.round(blur/2)}px rgba(${darkShadow.join(',')}, 0.2),
        inset -${Math.round(xOffset/2)}px -${Math.round(yOffset/2)}px ${Math.round(blur/2)}px rgba(${lightShadow.join(',')}, 0.7);
}`;
        
        // Update code display
        const codeElement = document.getElementById('cssCode');
        if (codeElement) {
            codeElement.textContent = css;
            if (typeof Prism !== 'undefined') {
                Prism.highlightElement(codeElement);
            }
        }
        
        return css;
    }
    
    generateFigma() {
        const { xOffset, yOffset, radius, blur, backgroundColor, lightShadowColor, darkShadowColor } = this.parameters;
        
        const figmaCode = `// Figma CSS for Neumorphic Element
// Copy this to your Figma plugin or use as reference

Fill: ${backgroundColor}
Border Radius: ${radius}px

Effects:
Drop Shadow:
  X: ${xOffset}px, Y: ${yOffset}px
  Blur: ${blur}px
  Color: ${darkShadowColor}20 (20% opacity)

Drop Shadow:
  X: -${xOffset}px, Y: -${yOffset}px  
  Blur: ${blur}px
  Color: ${lightShadowColor}B3 (70% opacity)

// For inner shadows, use Inner Shadow effect:
Inner Shadow:
  X: ${xOffset}px, Y: ${yOffset}px
  Blur: ${blur}px
  Color: ${darkShadowColor}33 (20% opacity)

Inner Shadow:
  X: -${xOffset}px, Y: -${yOffset}px
  Blur: ${blur}px
  Color: ${lightShadowColor}B3 (70% opacity)`;

        document.getElementById('codeOutput').textContent = figmaCode;
        
        // Update syntax highlighting
        if (typeof Prism !== 'undefined') {
            Prism.highlightElement(document.getElementById('codeOutput'));
        }
    }
    
    generateTSX() {
        const { xOffset, yOffset, radius, intensity, blur, backgroundColor } = this.parameters;
        
        const bgRgb = this.hexToRgb(backgroundColor);
        const lightShadow = this.adjustBrightness(bgRgb, intensity / 100 * 0.3);
        const darkShadow = this.adjustBrightness(bgRgb, -intensity / 100 * 0.3);
        
        let tsx = `import { motion, useAnimation } from "framer-motion"
import { useState, useEffect } from "react"

interface NeumorphicCardProps {
  albumTitle?: string
  artistName?: string
  coverImageUrl?: string
  backgroundColor?: string
  isPlaying?: boolean
  onPlayToggle?: () => void
}

export default function NeumorphicCard({
  albumTitle = "ALBUM",
  artistName = "Artist",
  coverImageUrl = "/api/placeholder/200/200",
  backgroundColor = "${backgroundColor}",
  isPlaying = false,
  onPlayToggle
}: NeumorphicCardProps) {
  
  const [isHovered, setIsHovered] = useState(false)
  const cardAnimation = useAnimation()
  
  useEffect(() => {
    if (isPlaying) {
      cardAnimation.start({
        scale: [1, 1.02, 1],
        transition: {
          duration: 2,
          repeat: Infinity,
          ease: "easeInOut"
        }
      })
    } else {
      cardAnimation.start({
        scale: 1,
        transition: {
          duration: 0.5,
          ease: "easeOut"
        }
      })
    }
  }, [isPlaying, cardAnimation])

  return (
    <div
      style={{
        minHeight: "100vh",
        background: "${backgroundColor}",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        padding: "2rem",
        position: "relative"
      }}
    >
      {/* Background Title */}
      <motion.div
        initial={{ opacity: 0.1, scale: 0.8 }}
        animate={{ 
          opacity: isHovered ? 0.15 : 0.1,
          scale: isHovered ? 1.02 : 1
        }}
        transition={{ duration: 0.3 }}
        style={{
          position: "absolute",
          top: "20%",
          left: "50%",
          transform: "translateX(-50%)",
          fontSize: "clamp(4rem, 15vw, 12rem)",
          fontWeight: "900",
          color: "#2c3e50",
          fontFamily: "'Helvetica Neue', Arial, sans-serif",
          letterSpacing: "0.1em",
          userSelect: "none",
          zIndex: 1,
          textAlign: "center"
        }}
      >
        {albumTitle}
      </motion.div>

      {/* Neumorphic Card */}
      <motion.div
        animate={cardAnimation}
        onHoverStart={() => setIsHovered(true)}
        onHoverEnd={() => setIsHovered(false)}
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        onClick={onPlayToggle}
        style={{
          width: "300px",
          height: "200px",
          background: "${backgroundColor}",
          borderRadius: "${radius}px",
          boxShadow: \`
            ${xOffset}px ${yOffset}px ${blur}px rgba(${darkShadow.join(',')}, 0.2),
            -${xOffset}px -${yOffset}px ${blur}px rgba(${lightShadow.join(',')}, 0.7)
          \`,
          padding: "2rem",
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "center",
          cursor: "pointer",
          transition: "all 0.3s ease",
          position: "relative",
          zIndex: 2
        }}
      >
        {/* Album Cover */}
        <motion.div
          animate={{
            rotate: isPlaying ? 360 : 0,
          }}
          transition={{
            duration: isPlaying ? 3 : 0.5,
            repeat: isPlaying ? Infinity : 0,
            ease: isPlaying ? "linear" : "easeOut"
          }}
          style={{
            width: "80px",
            height: "80px",
            borderRadius: "50%",
            background: \`linear-gradient(135deg, 
              rgb(${lightShadow.join(',')}), 
              rgb(${darkShadow.join(',')}))\`,
            marginBottom: "1rem",
            position: "relative",
            boxShadow: \`
              inset ${Math.round(xOffset/2)}px ${Math.round(yOffset/2)}px ${Math.round(blur/2)}px rgba(${darkShadow.join(',')}, 0.3),
              inset -${Math.round(xOffset/2)}px -${Math.round(yOffset/2)}px ${Math.round(blur/2)}px rgba(${lightShadow.join(',')}, 0.8)
            \`
          }}
        >
          {/* Center dot */}
          <div
            style={{
              position: "absolute",
              top: "50%",
              left: "50%",
              transform: "translate(-50%, -50%)",
              width: "8px",
              height: "8px",
              background: "#333",
              borderRadius: "50%"
            }}
          />
        </motion.div>

        {/* Artist Name */}
        <h3
          style={{
            margin: 0,
            fontSize: "1.2rem",
            fontWeight: "600",
            color: "#34495e",
            fontFamily: "'San Francisco', 'Segoe UI', system-ui, sans-serif",
            textAlign: "center"
          }}
        >
          {artistName}
        </h3>

        {/* Play Status */}
        <motion.p
          animate={{
            opacity: isPlaying ? 1 : 0.6,
            scale: isPlaying ? 1.05 : 1
          }}
          style={{
            margin: "0.5rem 0 0 0",
            fontSize: "0.8rem",
            color: "#7f8c8d",
            fontFamily: "'San Francisco', 'Segoe UI', system-ui, sans-serif"
          }}
        >
          {isPlaying ? "♪ Playing..." : "Click to play"}
        </motion.p>

        {/* Playing Indicator */}
        {isPlaying && (
          <motion.div
            initial={{ opacity: 0, scale: 0 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0 }}
            style={{
              position: "absolute",
              top: "10px",
              right: "10px",
              width: "12px",
              height: "12px",
              backgroundColor: "#e74c3c",
              borderRadius: "50%",
              boxShadow: "0 0 10px rgba(231, 76, 60, 0.6)"
            }}
          >
            <motion.div
              animate={{
                scale: [1, 1.3, 1],
                opacity: [1, 0.5, 1]
              }}
              transition={{
                duration: 1,
                repeat: Infinity,
                ease: "easeInOut"
              }}
              style={{
                width: "100%",
                height: "100%",
                backgroundColor: "#e74c3c",
                borderRadius: "50%"
              }}
            />
          </motion.div>
        )}
      </motion.div>
    </div>
  )
}`;
        
        // Update TSX code display
        const tsxElement = document.getElementById('tsxCode');
        if (tsxElement) {
            tsxElement.textContent = tsx;
            if (typeof Prism !== 'undefined') {
                Prism.highlightElement(tsxElement);
            }
        }
        
        return tsx;
    }
    
    switchCodeType(type) {
        this.currentCodeType = type;
        const cssContainer = document.querySelector('#cssCode').parentElement;
        const tsxContainer = document.querySelector('#tsxCode').parentElement;
        
        if (type === 'css') {
            cssContainer.style.display = 'block';
            tsxContainer.style.display = 'none';
        } else if (type === 'tsx') {
            cssContainer.style.display = 'none';
            tsxContainer.style.display = 'block';
        }
    }
    
    copyCurrentCode() {
        let code;
        if (this.currentCodeType === 'css') {
            code = this.generateCSS();
        } else {
            code = this.generateTSX();
        }
        
        if (navigator.clipboard && window.isSecureContext) {
            navigator.clipboard.writeText(code).then(() => {
                this.showNotification(`${this.currentCodeType.toUpperCase()} copied to clipboard!`, 'success');
            }).catch(() => {
                this.fallbackCopyTextToClipboard(code);
            });
        } else {
            this.fallbackCopyTextToClipboard(code);
        }
    }
    
    applyPreset(preset) {
        Object.assign(this.parameters, preset);
        
        // Update UI controls
        Object.keys(preset).forEach(key => {
            const slider = document.getElementById(key);
            const valueDisplay = document.getElementById(key + 'Value');
            
            if (slider) {
                slider.value = preset[key];
            }
            if (valueDisplay) {
                valueDisplay.textContent = preset[key];
            }
        });
        
        this.updatePreview();
        this.generateCSS();
    }
    
    async handleFileUpload(file) {
        const statusElement = document.getElementById('uploadStatus');
        
        if (!file) return;
        
        // Validate file type
        const allowedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/svg+xml'];
        if (!allowedTypes.includes(file.type)) {
            this.showNotification('Please upload a valid image file (JPG, PNG, SVG)', 'error');
            return;
        }
        
        // Validate file size (5MB)
        if (file.size > 5 * 1024 * 1024) {
            this.showNotification('File size must be less than 5MB', 'error');
            return;
        }
        
        statusElement.innerHTML = '<small class="text-primary">Analyzing image...</small>';
        
        try {
            const formData = new FormData();
            formData.append('file', file);
            
            const response = await fetch('/upload', {
                method: 'POST',
                body: formData
            });
            
            const result = await response.json();
            
            if (result.success) {
                this.applyImageAnalysis(result);
                statusElement.innerHTML = '<small class="text-success">✓ Image analyzed successfully</small>';
                this.showNotification('Image analyzed and parameters applied!', 'success');
            } else {
                statusElement.innerHTML = '<small class="text-danger">✗ Analysis failed</small>';
                this.showNotification(result.error || 'Failed to analyze image', 'error');
            }
        } catch (error) {
            console.error('Upload error:', error);
            statusElement.innerHTML = '<small class="text-danger">✗ Upload failed</small>';
            this.showNotification('Failed to upload image', 'error');
        }
    }
    
    applyImageAnalysis(result) {
        const { suggestedParameters, dominantColors } = result;
        
        if (suggestedParameters) {
            // Apply suggested parameters
            Object.assign(this.parameters, suggestedParameters);
            
            // Update UI controls
            Object.keys(suggestedParameters).forEach(key => {
                const slider = document.getElementById(key);
                const valueDisplay = document.getElementById(key + 'Value');
                
                if (slider && key !== 'backgroundColor') {
                    slider.value = suggestedParameters[key];
                }
                if (valueDisplay && key !== 'backgroundColor') {
                    valueDisplay.textContent = suggestedParameters[key];
                }
            });
            
            // Update color picker
            if (suggestedParameters.backgroundColor) {
                const colorPicker = document.getElementById('colorPicker');
                const colorHex = document.getElementById('colorHex');
                
                if (colorPicker) colorPicker.value = suggestedParameters.backgroundColor;
                if (colorHex) colorHex.value = suggestedParameters.backgroundColor;
            }
            
            this.updatePreview();
            this.generateCSS();
        }
    }
    
    copyCSS() {
        const css = this.generateCSS();
        
        if (navigator.clipboard && window.isSecureContext) {
            navigator.clipboard.writeText(css).then(() => {
                this.showNotification('CSS copied to clipboard!', 'success');
            }).catch(() => {
                this.fallbackCopyTextToClipboard(css);
            });
        } else {
            this.fallbackCopyTextToClipboard(css);
        }
    }
    
    fallbackCopyTextToClipboard(text) {
        const textArea = document.createElement('textarea');
        textArea.value = text;
        textArea.style.position = 'fixed';
        textArea.style.left = '-999999px';
        textArea.style.top = '-999999px';
        document.body.appendChild(textArea);
        textArea.focus();
        textArea.select();
        
        try {
            document.execCommand('copy');
            this.showNotification('CSS copied to clipboard!', 'success');
        } catch (err) {
            this.showNotification('Failed to copy CSS. Please copy manually.', 'error');
        }
        
        document.body.removeChild(textArea);
    }
    
    exportSVG() {
        const { xOffset, yOffset, radius, intensity, blur, backgroundColor } = this.parameters;
        const bgRgb = this.hexToRgb(backgroundColor);
        const lightShadow = this.adjustBrightness(bgRgb, intensity / 100 * 0.3);
        const darkShadow = this.adjustBrightness(bgRgb, -intensity / 100 * 0.3);
        
        const svg = `
<svg width="240" height="160" viewBox="0 0 240 160" xmlns="http://www.w3.org/2000/svg">
    <defs>
        <filter id="neumorphic" x="-50%" y="-50%" width="200%" height="200%">
            <feDropShadow dx="${xOffset}" dy="${yOffset}" stdDeviation="${blur/2}" 
                         flood-color="rgb(${darkShadow.join(',')})" flood-opacity="0.2"/>
            <feDropShadow dx="${-xOffset}" dy="${-yOffset}" stdDeviation="${blur/2}" 
                         flood-color="rgb(${lightShadow.join(',')})" flood-opacity="0.7"/>
        </filter>
    </defs>
    
    <rect width="240" height="160" fill="${backgroundColor}"/>
    <rect x="40" y="40" width="160" height="80" rx="${radius}" 
          fill="${backgroundColor}" filter="url(#neumorphic)"/>
</svg>`.trim();
        
        this.downloadFile(svg, 'neumorphic-element.svg', 'image/svg+xml');
    }
    
    exportPNG() {
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');
        canvas.width = 400;
        canvas.height = 300;
        
        // Fill background
        ctx.fillStyle = this.parameters.backgroundColor;
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        
        // Draw neumorphic element (simplified version)
        const elementX = 50;
        const elementY = 50;
        const elementWidth = 300;
        const elementHeight = 200;
        const radius = this.parameters.radius;
        
        // Create rounded rectangle path
        ctx.beginPath();
        ctx.roundRect(elementX, elementY, elementWidth, elementHeight, radius);
        ctx.fillStyle = this.parameters.buttonColor || this.parameters.backgroundColor;
        ctx.fill();
        
        // Convert to blob and download
        canvas.toBlob((blob) => {
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = 'neumorphic-element.png';
            a.style.display = 'none';
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
            
            this.showNotification('PNG exported successfully!', 'success');
        }, 'image/png');
    }0, 160);
        
        // This is a simplified PNG export. For production, you'd want to
        // implement proper shadow rendering using canvas APIs
        ctx.fillStyle = this.parameters.backgroundColor;
        ctx.roundRect(40, 40, 160, 80, this.parameters.radius);
        ctx.fill();
        
        canvas.toBlob((blob) => {
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = 'neumorphic-element.png';
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
        }, 'image/png');
    }
    
    downloadFile(content, filename, mimeType) {
        try {
            const blob = new Blob([content], { type: mimeType });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = filename;
            a.style.display = 'none';
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
            
            // Show success message
            this.showNotification('Download started successfully!', 'success');
        } catch (error) {
            console.error('Download failed:', error);
            this.showNotification('Download failed. Please try again.', 'error');
        }
    }
    
    showNotification(message, type) {
        // Create notification element
        const notification = document.createElement('div');
        notification.className = `alert alert-${type === 'success' ? 'success' : 'danger'} position-fixed`;
        notification.style.top = '20px';
        notification.style.right = '20px';
        notification.style.zIndex = '9999';
        notification.textContent = message;
        
        document.body.appendChild(notification);
        
        // Remove after 3 seconds
        setTimeout(() => {
            if (notification.parentNode) {
                notification.parentNode.removeChild(notification);
            }
        }, 3000);
    }
    
    hexToRgb(hex) {
        const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
        return result ? [
            parseInt(result[1], 16),
            parseInt(result[2], 16),
            parseInt(result[3], 16)
        ] : [224, 224, 224];
    }
    
    adjustBrightness(rgb, factor) {
        return rgb.map(c => Math.max(0, Math.min(255, Math.round(c + c * factor))));
    }

    async saveDesign() {
        const name = prompt('Enter a name for this design:');
        if (!name) return;

        const designData = {
            name: name,
            x_offset: this.parameters.xOffset,
            y_offset: this.parameters.yOffset,
            radius: this.parameters.radius,
            intensity: this.parameters.intensity,
            blur: this.parameters.blur,
            background_color: this.parameters.backgroundColor,
            shape: this.currentShape
        };

        try {
            const response = await fetch('/save-design', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(designData)
            });

            const result = await response.json();

            if (result.success) {
                this.showNotification('Design saved successfully!', 'success');
                this.loadSavedDesigns();
            } else {
                this.showNotification(result.error || 'Failed to save design', 'error');
            }
        } catch (error) {
            console.error('Save error:', error);
            this.showNotification('Failed to save design', 'error');
        }
    }

    async loadSavedDesigns() {
        try {
            const response = await fetch('/designs');
            const result = await response.json();

            if (result.success) {
                this.displaySavedDesigns(result.designs);
            }
        } catch (error) {
            console.error('Load designs error:', error);
        }
    }

    displaySavedDesigns(designs) {
        const container = document.getElementById('savedDesigns');
        if (!container) return;

        if (designs.length === 0) {
            container.innerHTML = '<p class="text-muted text-center">No saved designs yet</p>';
            return;
        }

        container.innerHTML = designs.map(design => `
            <div class="design-item" data-id="${design.id}">
                <div class="design-preview" style="background: ${design.background_color}; border-radius: ${design.radius}px; box-shadow: ${design.x_offset}px ${design.y_offset}px ${design.blur}px rgba(0,0,0,0.2), -${design.x_offset}px -${design.y_offset}px ${design.blur}px rgba(255,255,255,0.7);"></div>
                <div class="design-info">
                    <p class="design-name">${design.name}</p>
                    <p class="design-date">${new Date(design.created_at).toLocaleDateString()}</p>
                </div>
                <div class="design-actions">
                    <button class="design-delete" onclick="tool.deleteDesign(${design.id})" title="Delete">×</button>
                </div>
            </div>
        `).join('');

        // Add click listeners to load designs
        container.querySelectorAll('.design-item').forEach(item => {
            item.addEventListener('click', (e) => {
                if (!e.target.classList.contains('design-delete')) {
                    this.loadDesign(parseInt(item.dataset.id));
                }
            });
        });
    }

    async loadDesign(designId) {
        try {
            const response = await fetch(`/load-design/${designId}`);
            const result = await response.json();

            if (result.success) {
                const design = result.design;
                
                // Update parameters
                Object.assign(this.parameters, {
                    xOffset: design.x_offset,
                    yOffset: design.y_offset,
                    radius: design.radius,
                    intensity: design.intensity,
                    blur: design.blur,
                    backgroundColor: design.background_color
                });

                this.currentShape = design.shape;

                // Update UI controls
                Object.keys(this.parameters).forEach(key => {
                    const slider = document.getElementById(key);
                    const valueDisplay = document.getElementById(key + 'Value');
                    
                    if (slider && key !== 'backgroundColor') {
                        slider.value = this.parameters[key];
                    }
                    if (valueDisplay && key !== 'backgroundColor') {
                        valueDisplay.textContent = this.parameters[key];
                    }
                });

                // Update color picker
                const colorPicker = document.getElementById('colorPicker');
                const colorHex = document.getElementById('colorHex');
                if (colorPicker) colorPicker.value = this.parameters.backgroundColor;
                if (colorHex) colorHex.value = this.parameters.backgroundColor;

                // Update shape selector
                document.querySelectorAll('.shape-btn').forEach(btn => {
                    btn.classList.toggle('active', btn.dataset.shape === this.currentShape);
                });

                this.updatePreview();
                this.generateCSS();
                this.showNotification('Design loaded successfully!', 'success');
            } else {
                this.showNotification(result.error || 'Failed to load design', 'error');
            }
        } catch (error) {
            console.error('Load design error:', error);
            this.showNotification('Failed to load design', 'error');
        }
    }

    async deleteDesign(designId) {
        if (!confirm('Are you sure you want to delete this design?')) {
            return;
        }

        try {
            const response = await fetch(`/delete-design/${designId}`, {
                method: 'DELETE'
            });

            const result = await response.json();

            if (result.success) {
                this.showNotification('Design deleted successfully!', 'success');
                this.loadSavedDesigns();
            } else {
                this.showNotification(result.error || 'Failed to delete design', 'error');
            }
        } catch (error) {
            console.error('Delete design error:', error);
            this.showNotification('Failed to delete design', 'error');
        }
    }
}

// Add canvas roundRect polyfill for older browsers
if (!CanvasRenderingContext2D.prototype.roundRect) {
    CanvasRenderingContext2D.prototype.roundRect = function (x, y, w, h, r) {
        if (w < 2 * r) r = w / 2;
        if (h < 2 * r) r = h / 2;
        this.beginPath();
        this.moveTo(x + r, y);
        this.arcTo(x + w, y, x + w, y + h, r);
        this.arcTo(x + w, y + h, x, y + h, r);
        this.arcTo(x, y + h, x, y, r);
        this.arcTo(x, y, x + w, y, r);
        this.closePath();
        return this;
    };
}

// Make tool globally available for design deletion
let tool;

// Initialize the tool when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    tool = new NeumorphismTool();
});
