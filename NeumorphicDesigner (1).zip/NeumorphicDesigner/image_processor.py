import os
import colorsys
from PIL import Image, ImageStat
import logging

class ImageProcessor:
    """Process images to extract neumorphic design parameters"""
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
    
    def analyze_image(self, image_path):
        """Analyze an image and extract neumorphic parameters"""
        try:
            with Image.open(image_path) as img:
                # Convert to RGB if necessary
                if img.mode != 'RGB':
                    img = img.convert('RGB')
                
                # Get dominant colors
                dominant_colors = self._get_dominant_colors(img)
                
                # Analyze shadows and highlights
                shadow_data = self._analyze_shadows(img)
                
                # Calculate suggested parameters
                parameters = self._calculate_parameters(dominant_colors, shadow_data)
                
                return {
                    'success': True,
                    'dominantColors': dominant_colors,
                    'suggestedParameters': parameters,
                    'imageAnalysis': shadow_data
                }
                
        except Exception as e:
            self.logger.error(f"Image analysis error: {str(e)}")
            return {
                'success': False,
                'error': f'Failed to analyze image: {str(e)}'
            }
    
    def _get_dominant_colors(self, img, num_colors=5):
        """Extract dominant colors from image"""
        # Resize for faster processing
        img_small = img.resize((150, 150))
        
        # Get color histogram
        colors = img_small.getcolors(maxcolors=256*256*256)
        if not colors:
            return ['#e0e0e0']
        
        # Sort by frequency and get top colors
        colors.sort(key=lambda x: x[0], reverse=True)
        
        dominant = []
        for count, color in colors[:num_colors]:
            hex_color = '#{:02x}{:02x}{:02x}'.format(*color)
            dominant.append(hex_color)
        
        return dominant
    
    def _analyze_shadows(self, img):
        """Analyze shadow and highlight areas"""
        # Convert to grayscale for luminosity analysis
        gray = img.convert('L')
        
        # Get basic statistics
        stat = ImageStat.Stat(gray)
        
        # Calculate brightness distribution
        brightness_mean = stat.mean[0]
        brightness_stddev = stat.stddev[0]
        
        # Analyze contrast
        contrast = brightness_stddev / 128.0  # Normalize to 0-1
        
        return {
            'brightness': brightness_mean / 255.0,  # Normalize to 0-1
            'contrast': min(1.0, contrast),
            'hasStrongShadows': contrast > 0.3,
            'isHighKey': brightness_mean > 180,
            'isLowKey': brightness_mean < 75
        }
    
    def _calculate_parameters(self, colors, shadow_data):
        """Calculate suggested neumorphic parameters based on analysis"""
        # Base parameters
        base_offset = 10
        base_radius = 50
        base_intensity = 50
        base_blur = 20
        
        # Adjust based on image characteristics
        if shadow_data['hasStrongShadows']:
            base_intensity = min(75, base_intensity + 20)
            base_blur = min(40, base_blur + 10)
        
        if shadow_data['isHighKey']:
            base_offset = max(5, base_offset - 3)
            base_intensity = max(30, base_intensity - 15)
        elif shadow_data['isLowKey']:
            base_offset = min(20, base_offset + 5)
            base_intensity = min(80, base_intensity + 20)
        
        # Use the most suitable background color (usually the most frequent)
        background_color = colors[0] if colors else '#e0e0e0'
        
        # Ensure the background is light enough for neumorphism
        bg_rgb = self._hex_to_rgb(background_color)
        brightness = sum(bg_rgb) / 3
        
        if brightness < 150:  # Too dark, lighten it
            factor = 150 / brightness
            bg_rgb = tuple(min(255, int(c * factor)) for c in bg_rgb)
            background_color = '#{:02x}{:02x}{:02x}'.format(*bg_rgb)
        
        return {
            'xOffset': base_offset,
            'yOffset': base_offset,
            'radius': base_radius,
            'intensity': base_intensity,
            'blur': base_blur,
            'backgroundColor': background_color
        }
    
    def _hex_to_rgb(self, hex_color):
        """Convert hex color to RGB tuple"""
        hex_color = hex_color.lstrip('#')
        return tuple(int(hex_color[i:i+2], 16) for i in (0, 2, 4))
